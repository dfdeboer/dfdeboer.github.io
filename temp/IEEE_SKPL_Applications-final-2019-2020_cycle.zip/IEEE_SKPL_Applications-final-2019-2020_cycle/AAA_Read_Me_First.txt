This directory contains all the SKPL applications that passed the first evaluation.
These are from the 2019-2020 cycle of the project.

In the directory that contains this read-me file there is exactly one application file per library that applied.  A few libraries split their applications into multiple files for various reasons.  Those additional files are in the directory labeled "SKPL_Additional_Files."  Each main application file that was split up has annotations in it to help you find the additional related files.  

Subdirectories of this directory contain the evaluation forms and the letters sent to each library to acknowledge receipt of their application.  There is a one-to-one correspondence between the application file in this directory, the evaluation file in the directory labeled "SKPL_Part_1_Evaluations" and the acknowledgement letter in the folder "SKPL_Part_1_Acknowledgement_Letters.  If you strip off the state abbreviation and city name from a file name in this folder what remains is the name of the file as it was received.  The addition of the state abbreviation and city name was done to facilitate understanding the relationships between the files.  

Several libraries submitted incomplete or technically bungled applications.  Doug De Boer worked with these libraries to correct the deficiencies.  Thus, every library that tried to apply ultimately succeeded.  A few libraries did not correct every detail in their application but did clarify their intentions via e-mail correspondence with Doug De Boer.  In these few cases Doug De Boer annotated their application to fill in missing detail.  The annotations are always in green text surrounded by a red box.  These annotations are obvious so that the reader can clearly distinguish the original application from the annotations. 

All the applications have been annotated to show the IEEE section of Region 4 in which they are located.  

--dDB
