function y=arg(x)
%
%  y=arg(x)  Returns the argument of the complex number array, matrix, x
%            This function is similar to Malab's built in "angle" 
%            function except for the range of the result and a 
%            "threshold" for roundoff errors so that tiny complex
%            numbers result in arg = 0 instead of some arbitrary 
%            result that only reflects the action of round-off error.
%
%            x = a complex number, vector, matrix
%            y = a real number, vector, matrix the same size as size(x)
%                 -0 <= y < 2*pi
%            Note that mathematicians usually use the range -pi <= y <= pi
%            as in Matlab's "angle" function.  
%
%            10/31/94 Doug De Boer
%            03/28/06 updated by Doug De Boer to add threshold feature.

   t = 5e-15;   % "threshold"--tiny complex numbers have magnitude < t
                % also, if -t < angle(x) < t then snap result to zero.  
   xx = x;
   xx(abs(xx)<t) = xx(abs(xx)<t).*0;   
   y = atan2(imag(xx), real(xx));
   y(y<0) = y(y<0) + 2*pi;        %Adjust fundamental range.  
   y(y>2*pi-t) = y(y>2*pi-t).*0;  %snap tiny angles to zero
   y(y<t) = y(y<t).*0;            %snap tiny angles to zero.
   return

