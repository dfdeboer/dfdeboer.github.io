function y = triangle(t)
%
%  The unit (area) triangle function
%  This function calls rect(t)
%  (rect.m must be present in the working directory or 
%      it must be installed as a toolbox function in order for 
%      triangle(t) to work.)  
%
%  t = a vector, 
%      the independent variable (sample number, time, etc.)
%
%  triangle(t) = 1 - |t| if 1.0 <= t <= 1.0
%            otherwise triangle(t) = 0
%
%  EXAMPLE  
%  >>t = [-1.4 : 0.2 : 1.2]
%  t =
%      -1.4 -1.2 -1.0 -0.8 -0.6 -0.4 -0.2  0.0  0.2  0.4  0.6  0.8  1.0  1.2
%
%  >>triangle(t)
%  ans = 
%       0.0  0.0  0.0  0.2  0.4  0.6  0.8  1.0  0.8  0.6  0.4  0.2  0.0  0.0
%
%  NOTE: If "delay" and "width" are scalars, a possible way 
%  to invoke triangle is. . .
%  y = triangle((t - delay)/width)
%
%  Written by Douglas F. De Boer 1/21/2008
%  Comments added 1/18/2010, comments updated 1/13/2016

y = (t + ones(size(t))).*rect(t + 0.5) + (-t + ones(size(t))).*rect(t - 0.5);
y(find(t==0)) = y(find(t==0))/2;

