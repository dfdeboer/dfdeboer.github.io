function y=dot(A,B,dx)
%
%  DOT(A,B,dx)  Finds the dot (or inner or scalar) product of two functions.
%     A  Column vector, the values of A(x)
%     B  Column vector, the values of B(x)
%    dx  the increment made in x at each step of the evaluation of A(x) and B(x)
%
%        Written by Doug De Boer, 6/28/94

   [rowsA,columns]=size(A);
   if columns ~= 1
      error('The vector A must be a column vector')
      return
   end

   [rowsB,columns]=size(B);
   if columns ~= 1
      error('The vector B must be a column vector')
      return
   end

   if rowsA ~= rowsB
      error('The vectors A and B must be the same size')
      return
   end

   C = A.'.*B';
   y = simpson(C.',dx);

