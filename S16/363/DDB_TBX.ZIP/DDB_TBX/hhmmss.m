function clkstr = hhmmss(clk,detail,format)
%  clkstr = hhmmss12(clk)
%
%     Converts a row vector (such as clock) to a string giving the hour
%     minute and second with AM or PM appended in 12 hour format 'hh:mm:ss XM'
%
%     clk = A row vector, [year month day hour min sec]
%           The year, month, and day are ignored and may be omitted.
%           Fractions of a second are ignored.
%           The hour may be omitted, in which case min may be > 59
%           The hour and min may be omitted, in which case sec may be >= 60.  
%           The built in variables CLOCK and TOC are convenient to pass for clk.
%
%     detail  If detail equals 2, then seconds are omitted giving hh:mm 
%             If detail equals 3, then seconds are included, hh:mm:ss
%             detail is optional, the default is 3.
%     format  If format is 24, the hour is 00-23 00:00:00 being midnight.
%             If format is 12, the hour is 1-12 and AM or PM is appended.
%             If format is 0,  the hour is 0 or more, elapsed time indicated.  
%             format is optional, the default is 12 unless 
%             length(clk) < 3 in which case the default is 0
%     clkstr = A string of characters giving the time
%
%  1/9/94 Douglas De Boer, part of the DDB_TBX toolbox

   if nargin == 1
      detail = 3;
      if length(clk) < 3, format = 0; else, format = 12; end
   elseif nargin == 2
      if length(clk) < 3, format = 0; else, format = 12; end
   end
%
% EXTRACT HOURS MINUTES AND SECONDS FROM THE GIVEN ROW VECTOR
%
   L = length(clk);
   if L == 1
      hour = floor(clk/3600);
      min  = floor((clk-3600*hour)/60);
      sec  = floor(clk-3600*hour-60*min);
   elseif L == 2
      sec  = floor(clk(2));
      if sec >= 60, error(['seconds > 60, sec = ' num2str(clk(2))]); end
      hour = floor(clk(1)/60)
      min  = floor((clk(1)-60*hour))
      if min ~= floor(min), error('Fractional minutes not allowed'); end
   elseif L > 2
      sec  = floor(clk(L));
      if sec >= 60, error(['seconds > 60, sec = ' num2str(clk(L))]); end
      min  = clk(L-1);
      if min ~= floor(min), error('Fractional minutes not allowed'); end
      if min >= 60, error(['minutes > 60, sec = ' num2str(clk(L-1))]); end
      hour = clk(L-2);
      if hour ~= floor(hour), error('Fractional hours not allowed'); end
   end
%
% TAKE CARE OF HOUR AND AM OR PM SUFFIX
%
   ampmstr = [];

   if format == 12
      if 10000*hour + 100*min + sec >= 120000
         ampmstr = ' PM';
      else
         ampmstr = ' AM';
      end
      if hour > 12, hour = hour - 12; end
      if hour <  1, hour = hour + 12; end
      pad = ' ';
   elseif format == 24
      pad = '0';
   else % assume elapsed time format
      pad = ' ';
   end
   if hour < 10 
      hourstr = [pad num2str(hour)]; 
   else 
      hourstr = num2str(hour); 
   end
%
% TAKE CARE OF MINUTES
%
      if min < 10
         minstr = [':0' num2str(min)];
      else
         minstr = [':'  num2str(min)];
      end
%
% TAKE CARE OF SECONDS
%
   if detail ~= 2, 
      if sec < 10
         secstr = [':0' num2str(sec)];
      else
         secstr = [':'  num2str(sec)];
      end
   else
      secstr = [];
   end
%
% ASSEMBLE OUTPUT STRING AND RETURN
%
   clkstr = [hourstr minstr secstr ampmstr];
   return

