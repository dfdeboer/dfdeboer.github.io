function [out, SEED] = rand_cn(NSIZE, VAR, MEAN, SEED)

% [out, SEED] = RAND_CN(NSIZE, VAR, MEAN, SEED) Generates a row vector of 
%               complex random numbers with gaussian distribution of the 
%               real and complex portions.  (Uses the box Muller method, the 
%               magnitude is Rayleigh distributed and the angle is uniform.)
%
%  NSIZE = Number of random numbers to generate
%  VAR   = Variance of the random numbers (optional, default is VAR = 1)
%  MEAN  = Mean of the random numbers (optional, default is MEAN = 0)
%  SEED  = Seed for random number generator (optional)

%           7/11/94 Doug De Boer

% Check input parameters

   if (nargin == 4) rand('seed',SEED); end
   if (nargin  < 3) MEAN = 0;          end
   if (nargin  < 2) VAR  = 1;          end

% Main code

   u     = 2*pi*rand(1,NSIZE);           % Uniform in 0 to 2pi
   r     = sqrt(-2*log(rand(1,NSIZE)));  % Rayleigh
   out   = r.*(cos(u)+j*sin(u));         % zero mean Gaussian, variance of 2
   out   = sqrt(0.5*VAR)*out + MEAN;

   if (nargout == 2)
      SEED = rand('seed');
   end

