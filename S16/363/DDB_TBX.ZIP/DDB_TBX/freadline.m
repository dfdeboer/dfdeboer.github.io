function line = freadline(FID)
%
%  line = freadline(FID)   Reads characters from the specified file and places
%                          them in the string 'line' until a carriage return
%                          (ASCII char 13, decimal) is encountered.  The
%                          carriage return is discarded.  If a line begins with
%                          a newline character (ASCII char 10 decimal) that is
%                          also discarded.
%
%     FID = A file identifier, obtained from the matlab 'fopen' function.
%    line = A character string containing all of what was on the line of the 
%           specified file, including spaces and commas, etc.  If the line 
%           in the file contained nothing (not even spaces) or if the line 
%           starts with an end-of-file mark, then 'line' will be null.  Use 
%           the matlab function 'ferror' to distinguish blank lines from the 
%           end-of-file condition.
%

%  12/28/94 Douglas De Boer

   line = [];                  % Clear the line
   S = fread(FID,1);
   while S == 10
      S = fread(FID,1);        % Read characters until something other than
   end                         %  a newline character is encountered

   while (S ~= 13) & (S ~= [])
      line = [line S];         % Assemble the line until a carriage return or
      S = fread(FID,1);        % end-of-file
   end

   line = setstr(line);        % Make it a character string

   return

