function [out, seed] = rand_bin(nsize, p, seed)

% [OUT, SEED] = RAND_BIN(NSIZE, P, SEED) Generates a sequence of random 
%                                        binary digits.
%
%  NSIZE = Number of binary digits to generate
%  P     = Probability that a digit equals 1
%  SEED  = Seed for random number generator

%           7/11/94 Doug De Boer

%  Check input parameters

   if (nargin == 3)
      rand('seed',seed)
   end

%  Generate NSIZE uniform random variates and transform into binary

   r     = rand(1,nsize);
   out   = (r > p);

   if (nargout == 2)
      seed = rand('seed');
   end

