function y = cardinality(x)
%
%  y = cardinality(x)
%
%  This function finds the cardinality of vector x.  (That is, it finds the
%  number of unique entries in vector x.)  If x is a matrix, this function 
%  finds the cardinality of each column of x and returns the results in row 
%  vector y.
%
%  If x is null then the cardinality is zero.
%

%  1/5/95 Douglas F. De Boer

   if x == []
      y = 0;
   else
      [i,j] = size(x);
      if i == 1    % If x is a row vector
         x = x(:); % change it to a column vector.
         i = j;
      end
      y = sum(diff(sort(x)) ~= 0) + (i ~= 1);
   end
   return

