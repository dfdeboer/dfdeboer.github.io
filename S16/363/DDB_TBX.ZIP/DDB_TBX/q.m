function y=q(x)
%
%  y = q(x) gives the Gaussian Probability Function defined as
%      (1/sqrt(2*pi))*integral from x to inf. of exp(-x*x/2) dx
%
%  7/31/95 Douglas F. De Boer

y = 0.5*(erfc(x/sqrt(2)));
return

