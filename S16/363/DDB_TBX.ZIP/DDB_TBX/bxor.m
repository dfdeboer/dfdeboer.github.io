function bin = bxor(a,b,maxbit,minbit)
%
%  bin = bxor(a,b)
%  bin = bxor(a,b,places)
%  bin = bxor(a,b,maxbit,minbit)
%
%  Binary exclusive or, with a and b being row vectors of ones and zeros

   nonbinary = abs(a-0.5) ~= 0.5;
   if any(nonbinary)
      error ('nonbinary input, first parameter');
   end

   nonbinary = abs(b-0.5) ~= 0.5;
   if any(nonbinary)
      error ('nonbinary input, second parameter');
   end

   la = length(a);
   lb = length(b);

   if la == lb
      bin = abs(a-b);
   elseif la > lb
      bin = abs(a - [b zeros(1,la-lb)]);
   else % la < lb
      bin = abs(b - [a zeros(1,lb-la)]);
   end

   if nargin == 3
      bin = bin(1:maxbit);
   elseif nargin == 4
      bin = bin(minbit:maxbit);
   end

   return

