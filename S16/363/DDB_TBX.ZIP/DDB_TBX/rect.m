function y=rect(t)
%
%  The unit rectangle function
%
%  t = a vector, 
%      the independent variable (sample number, time, etc.)
%
%  rect(t) = 1 if -0.5 <= t <= 0.5
%            otherwise rect(t) = 0
%
%  EXAMPLE  
%  >>t = [-1:0.25:1]
%  x =
%      -1.00 -0.75 -0.50 -0.25  0.00  0.25  0.50  0.75  1.00
%
%  >>rect(t)
%  ans = 
%       0     0     1     1     1     1     1     0     0
%
%  NOTE: If "delay" and "width" are scalars, a possible way 
%  to invoke rect is. . .
%  y = rect((t - delay)/width)
%
%  Written by Douglas F. De Boer 3/7/2001
%  Comments added 1/18/2008

t=abs(t);
t=t-0.5;
y=sign(-t);
y=y+1;
y=min(ones(size(y)),y);
