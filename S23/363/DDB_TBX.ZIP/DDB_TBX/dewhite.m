function out = dewhite(in)
%
%  out = dewhite(in)
%
%  Removes strings of spaces and comments from a string of text.
%  This is similar to deblank, but leaves one space between words.
%  Everything after a '%' and the '%' itself is treated as a comment and 
%  removed.  Null characters and trailing blanks are also removed.
%
%  in  = a string of text
%  out = text with comments and strings of spaces removed.
%
%  EXAMPLE:
%
%  in = 'How much  wood   would a   16 ft   woodchuck chuck? % I don''t know   '
%  dewhite(in)
%     ans = How much wood would a 16 ft woodchuck chuck?
%

%  12/28/94 Douglas De Boer

out = [];

if in ~= []

   if in(1) == ' '
      flag = 1;                    % flag indicates a leading space
   elseif in(1) == '%'
      flag = 2;                    % flag indicates a comment
   else
      flag = 0;                    % flag indicates no leading space or comment
      out = [out in(1)];
   end

   if length(in) > 1

      for i = 2:length(in)

         if in(i) == ' '

            if flag == 0;                
               flag = 1;                    
               out = [out in(i)];
            end

         elseif in(i) == '%'

            flag = 2;                       

         else

            if flag ~= 2                    
               flag = 0;                    
               out = [out in(i)];
            end

         end

      end

   end

end

if out ~= [] out = deblank(out); end   % remove a trailing space if necessary
return

