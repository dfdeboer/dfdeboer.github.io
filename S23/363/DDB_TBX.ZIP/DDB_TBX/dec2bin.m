function bin = dec2bin(dec,places)
%
%  bin = dec2bin(dec,places) 
%     Converts decimal integer to a row vector representing 
%     the number in unsigned binary format.
%
%     dec = a non-negative decimal integer to be converted.
%     places = an optional length for the output vector.  If more places are
%        needed for an accurate representation, then the most significant
%        places are truncated without warning.
%     bin = a row vector representing the powers of two that add up to dec.
%        bin(1) is the ones place (2^0's place) and bin(n+1) is the 2^n's place.
%
%  Note: if you want the bits to list across the screen in the usual order from
%  most to least significant, use fliplr:
%     fliplr(dec2bin(5,8)
%        ans = 0  0  0  0  0  1  0  1

%  1/3/95 Douglas De Boer

   if dec > 9007199254740991   % 2^53 - 1
      error('Integer must be <= 9,007,199,254,740,991 which is 2^53 - 1');
   end
   if dec < 0
      error('Integer must be >= zero');
   end
   if dec ~= floor(dec)
      error('Must be Integer');
   end

   maxp = 53;
   if nargin == 2
      if places > maxp
         error('More places specified than this hardware can deliver');
      end
      if places < 1
         error('Places must be >= 1');
      end
   else
      places = maxp;
   end

   bin = zeros(1,places);
   for i = 1:places
      dec = dec/2;
      bin(i) = 2*(dec - floor(dec));
      dec = floor(dec);
   end

   return

