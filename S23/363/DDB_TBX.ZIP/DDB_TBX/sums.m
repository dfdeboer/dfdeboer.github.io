function out = ddb_sums(in)
%
%  OUT = SUMS(IN) the Nth element of OUT is the sum of the elements 1 
%                 through N of IN
%
%        IN  = a vector 
%        OUT = a vector of sums, the same dimension as IN
%

%        7/12/94 Doug De Boer

   [rows, cols] = size(in);
   if (rows ~= 1)
      if (cols ~= 1)
         error('The parameter must be a vector')
      end
   end
   in = in(:); % force in to be a column vector
   temp = in;
   NSIZE = max(rows,cols);
   out = zeros(NSIZE,1);

   temp = 0;
   for N = 1:NSIZE
      temp = temp + in(N);
      out(N) = temp;
   end


