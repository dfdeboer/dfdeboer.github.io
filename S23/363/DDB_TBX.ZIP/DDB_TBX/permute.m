function y = permute(x,order)
%
%  y = permute(x,order)
%  
%  Rearranges the rows of x into the order specified by the vector order.
%
%  x     = any matrix
%
%  order = A vector of length equal to the number of rows in x.  The entries
%          of order specify the where the rows of x should go to in y.
%
%  y     = a matrix the same size as x with the rows re-ordered.
%
%  Examples:
%  y = permute(eye(3),[3 1 2])  | y = permute([1 2 3;4 5 6;7 8 9],[2 3 1])
%       y = 0  0  1             |      y = 4  5  6
%           1  0  0             |          7  8  9
%           0  1  0             |          1  2  3
%
% 1/6/95 Douglas De Boer

   [R,C] = size(x)

   if length(order) ~= R
      error('In y = permute(x,order) the length of order must = # rows in x')
   end

   y = zeros(R,C)

   for I = 1:R
      y(I,:) = x(order(I),:);
   end

   return
