function f = mod(x,m)
%
%  f = mod(x,m)
%  This function computes x modulo m such that x = k*y + f where:
%     m is a real scalar, the desired modulus
%     x is a real matrix, vector, or scalar; the input
%     f is the result, the same type variable as x such that for each 
%        element, f(i,j), this is true: 0 <= f(i,j) < m 
%     k is an integer
%     y is the same type as x and each element of y is an integer multiple of m
%
%  (note: taking the modulus of a number is not the same as taking the 
%  remainder.  The remainder has the sign of the original number.  examples:
%     mod(8,3) is 2 and   mod(-8,3) is 1 whereas
%     rem(8,3) is 2 and   rem(-8,3) is -2)
%     

%  Doug De Boer, 2/16/94

   if nargin ~= 2 error('requires two arguments'); end
   if length(m) ~= 1 error('the modulus must be a scalar'); end
   if imag(m) ~= 0 error('the modulus must be a real number'); end
   if max(max(abs(imag(x)))) ~= 0 error('every element of x must be real'); end

   f = (x - m*floor(x/m));

