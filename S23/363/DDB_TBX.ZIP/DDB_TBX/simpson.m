function y = simpson(F,dx)

%  SIMPSON(F,dx)  Integration by simpson's rule
%
%     F is a row or column vector containing the values of f(x) for x between 
%        two numbers, say a and b.  
%    dx is the increment made in x at each step of the evaluation of F(x)
%
%     Simpson's rule as typically found in a calculus book requires an even
%     number of intervals (odd number of sample values, 3 or more).  If this
%     is not the case, One of several Newton-Cotes formulas will be used
%     for a small portion of the integration to leave an even number of 
%     intervals for Simpson's rule to operate on. 
%
%        Written by Doug De Boer 7/7/94, rev. 6/19/95

%  For a summary of the rules employed here, see M. Abramowitz and
%  I.A. Stegun, Handbook of Mathematical Functions, p. 886, Dover 
%  Publications, 1972, originally published by the National Bureau of 
%  Standards, Applied Mathematics Series, No. 55, 1964. 

   [rows,columns]=size(F);
   if columns ~= 1
      if rows ~= 1
         error('The first parameter must be a row or column vector')
      end
   end

   F=F(:);
   rows=max(rows,columns);

% If rows = 1, 2, 4, 6, 8, or even > 8, a special case

   if rows == 1
      disp('Warning: simpson.m processced a vector with only 1 element.')
      y = 0;

   elseif rows == 2
      coef = [1 1];
      y = (dx/2)*coef*F;   % Trapezoidal rule

   elseif rows == 4
      coef = [1 3 3 1];
      y = (3*dx/8)*coef*F; % Simpson's 3/8 rule
      return

   elseif rows == 6
      coef = [19 75 50 50 75 19];
      y = (5*dx/288)*coef*F;

   elseif rows == 8
      coef = [751 3577 1323 2989 2989 1323 3577 751]; 
      y = (7*dx/17280)*coef*F;

   elseif rows == 10
      coef = [2857 15741 1080 19344 5778 5778 19344 1080 15741 2857];
      y = (9*dx/89600)*coef*F;

   elseif rem(rows,2) == 0
      % And even number of rows, greater than 10.  
      % Integrate the first (rows-9) samples using simpson's rule.
      % Integrate the last 10 intervals using a Newton-Cotes formula.
      rm9 = rows - 9;
      n   = 1:rm9;
      coef=4-2*ones(1,rm9).*rem(n,2);
      coef(1,1)=1;
      coef(1,rm9)=1;
      tailc = [2857 15741 1080 19344 5778 5778 19344 1080 15741 2857];
      y=(dx/3)*coef*F(1:rm9) + (9*dx/89600)*tailc*F(rm9:rows);

   else
      % an ordinary case for simpson's rule
      n   = 1:rows;
      coef=4-2*ones(1,rows).*rem(n,2);
      coef(1,1)=1;
      coef(1,rows)=1;
      tailc = [19 75 50 50 75 19];
      y=(dx/3)*coef*F;

   end

   return

